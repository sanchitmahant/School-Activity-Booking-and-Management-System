from reportlab.pdfgen import canvas
from io import BytesIO

def generate_invoice(name, activity):
    buffer = BytesIO()
    c = canvas.Canvas(buffer)
    c.drawString(100, 800, "School Activity Invoice")
    c.drawString(100, 780, f"Student: {name}")
    c.drawString(100, 760, f"Activity: {activity}")
    c.save()
    buffer.seek(0)
    return buffer

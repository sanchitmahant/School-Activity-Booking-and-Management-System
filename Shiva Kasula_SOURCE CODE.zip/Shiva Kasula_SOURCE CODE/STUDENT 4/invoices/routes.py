# Developed by Student 4 - Invoice Module
from flask import Blueprint, send_file, session
from invoices.pdf_gen import generate_invoice

invoices_bp = Blueprint('invoices', __name__)

@invoices_bp.route('/invoice')
def invoice():
    name = session.get('user_name', 'Guest')
    buffer = generate_invoice(name, 'Football Practice')
    return send_file(buffer, as_attachment=True, download_name='invoice.pdf', mimetype='application/pdf')

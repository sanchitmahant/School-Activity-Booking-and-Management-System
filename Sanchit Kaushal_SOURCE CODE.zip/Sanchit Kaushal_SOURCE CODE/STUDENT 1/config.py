import os
class Config:
    SECRET_KEY = 'devkey'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///school_activity_booking.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False

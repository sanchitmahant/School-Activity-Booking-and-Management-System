# Developed by Student 3 - Booking Module
from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from models.models import db
from datetime import date

bookings_bp = Blueprint('bookings', __name__, template_folder='../templates')

class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_name = db.Column(db.String(80))
    activity = db.Column(db.String(100))
    date = db.Column(db.Date, default=date.today)

@bookings_bp.route('/book', methods=['GET', 'POST'])
def book():
    if request.method == 'POST':
        user = session.get('user_name', 'Guest')
        activity = request.form['activity']
        today = date.today()
        # prevent double booking
        existing = Booking.query.filter_by(user_name=user, date=today).first()
        if existing:
            flash('You already booked an activity today!', 'danger')
        else:
            new = Booking(user_name=user, activity=activity)
            db.session.add(new)
            db.session.commit()
            flash('Booking successful!', 'success')
    bookings = Booking.query.all()
    return render_template('bookings.html', bookings=bookings)

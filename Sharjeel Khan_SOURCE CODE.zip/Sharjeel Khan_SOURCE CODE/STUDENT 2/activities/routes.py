# Developed by Student 2 - Activity Management Module
from flask import Blueprint, render_template, request, redirect, url_for, flash
from models.models import db

activities_bp = Blueprint('activities', __name__, template_folder='../templates')

class Activity(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100))
    category = db.Column(db.String(80))
    cost = db.Column(db.Float)

@activities_bp.route('/')
def list_activities():
    activities = Activity.query.all()
    return render_template('activities.html', activities=activities)

@activities_bp.route('/create', methods=['GET', 'POST'])
def create_activity():
    if request.method == 'POST':
        title = request.form['title']
        category = request.form['category']
        cost = float(request.form['cost'])
        new_activity = Activity(title=title, category=category, cost=cost)
        db.session.add(new_activity)
        db.session.commit()
        flash('Activity created!', 'success')
        return redirect(url_for('activities.list_activities'))
    return render_template('activity_form.html')
